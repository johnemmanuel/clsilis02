package com.qdx.instruments.clients.centaur;


import com.qdx.instruments.clients.centaur.tcp.AstmMessageDecoder;
import org.junit.jupiter.api.Test;

public class AstmMessageDecoderTest {

    @Test
    public void testDecodeAstmResultMessage() {
        String astmMessage
                = "H|\\\\^&|||Lab1|||||Host1||||P|1\\\\r"
                + "P|1||Doe^John||19800101|M\\\\r"
                + "O|1|1234||Test1|||||||||||O\\\\r"
                + "R|1|Result1|Test1|Positive\\\\r";

        AstmMessageDecoder decoder = new AstmMessageDecoder();
        decoder.decodeAstmResultMessage(astmMessage);
    }
}
