package com.qdx.instruments.clients.centaur.domain.testorder;

import com.qdx.instruments.clients.centaur.ResourceNotFoundException;
import com.qdx.instruments.clients.centaur.domain.testorder.TestOrder;
import java.util.concurrent.CompletableFuture;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class TestOrderService {

    @Autowired
    private TestOrderRepository repository;

    @Async
    public CompletableFuture<TestOrder> getTestOrderDetails(String patientId) {
        return CompletableFuture.supplyAsync(() -> repository.findByPatientId(patientId)
                .orElseThrow(() -> new ResourceNotFoundException()));
    }
}

