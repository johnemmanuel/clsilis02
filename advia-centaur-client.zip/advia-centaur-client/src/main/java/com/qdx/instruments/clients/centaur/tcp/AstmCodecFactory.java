package com.qdx.instruments.clients.centaur.tcp;

import org.apache.mina.filter.codec.demux.DemuxingProtocolCodecFactory;

public class AstmCodecFactory extends DemuxingProtocolCodecFactory {

    public AstmCodecFactory() {
        super.addMessageDecoder(AstmDecoder.class);
        super.addMessageEncoder(String.class, AstmEncoder.class);
    }
}
