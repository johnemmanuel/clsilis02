package com.qdx.instruments.clients.centaur.tcp;

import com.qdx.instruments.clients.centaur.ControlCharacters;
import com.qdx.instruments.clients.centaur.tcp.AstmMessageDecoder;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import java.util.concurrent.atomic.AtomicReference;

public class TcpClientHandler extends IoHandlerAdapter {

    private AtomicReference<TcpClientState> currentState = new AtomicReference<>(TcpClientState.IDLE);
    private StringBuilder astmMessage = new StringBuilder();

    @Override
    public void messageReceived(IoSession session, Object message) throws Exception {
        String receivedMsg = (String) message;

        switch (currentState.get()) {
            case IDLE:
                if (receivedMsg.contains(ControlCharacters.ENQ.getCharacterAsString())) {
                    session.write(ControlCharacters.ACK.getCharacterAsString());
                    currentState.set(TcpClientState.RECEIVING);
                }
                break;
            case RECEIVING:
                if (receivedMsg.contains(ControlCharacters.EOT.getCharacterAsString())) {
                    processCompleteMessage();
                    currentState.set(TcpClientState.PROCESSING);
                } else {
                    astmMessage.append(receivedMsg);
                    session.write(ControlCharacters.ACK.getCharacterAsString());
                }
                break;
            case PROCESSING:
                processResultMessage();
                currentState.set(TcpClientState.IDLE);
                break;
            default:
                break;
        }
    }

    private void processCompleteMessage() {
        String completeMessage = astmMessage.toString();
        System.out.println("Complete ASTM message received: " + completeMessage);
    }

    private void processResultMessage() {
        AstmMessageDecoder decoder = new AstmMessageDecoder();
        decoder.decodeAstmResultMessage(astmMessage.toString());
        astmMessage.setLength(0);
    }

    @Override
    public void sessionClosed(IoSession session) throws Exception {
        currentState.set(TcpClientState.IDLE);
    }
}
