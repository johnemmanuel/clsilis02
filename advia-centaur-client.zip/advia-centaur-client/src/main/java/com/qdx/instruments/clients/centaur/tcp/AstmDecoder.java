package com.qdx.instruments.clients.centaur.tcp;

import java.nio.charset.Charset;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.apache.mina.filter.codec.demux.MessageDecoderAdapter;
import org.apache.mina.filter.codec.demux.MessageDecoderResult;

public class AstmDecoder extends MessageDecoderAdapter {

    @Override
    public MessageDecoderResult decodable(IoSession session, IoBuffer in) {
        // Check for valid ASTM message, return OK if decodable
        return MessageDecoderResult.OK;
    }

    @Override
    public MessageDecoderResult decode(IoSession session, IoBuffer in, ProtocolDecoderOutput out) throws Exception {
        // Decode the ASTM message frames
        String message = in.getString(Charset.forName("ASCII").newDecoder());
        out.write(message);
        return MessageDecoderResult.OK;
    }
}
