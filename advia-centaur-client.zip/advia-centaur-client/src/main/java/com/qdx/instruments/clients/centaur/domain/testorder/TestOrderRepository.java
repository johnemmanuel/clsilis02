package com.qdx.instruments.clients.centaur.domain.testorder;

import com.qdx.instruments.clients.centaur.domain.testorder.TestOrder;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TestOrderRepository extends JpaRepository<TestOrder, Long> {

    Optional<TestOrder> findByPatientId(String patientId);
}
