package com.qdx.instruments.clients.centaur.tcp;

import java.nio.charset.Charset;
import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.apache.mina.filter.codec.demux.MessageEncoder;

/**
 *
 * @author johne
 */
public class AstmEncoder implements MessageEncoder {

    @Override
    public void encode(IoSession session, Object message, ProtocolEncoderOutput out) throws Exception {
        // Convert the message into ASTM frames and write to session
        String astmMessage = (String) message;
        IoBuffer buffer = IoBuffer.allocate(astmMessage.length()).setAutoExpand(true);
        buffer.putString(astmMessage, Charset.forName("ASCII").newEncoder());
        buffer.flip();
        out.write(buffer);
    }
}
