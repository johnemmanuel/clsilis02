package com.qdx.instruments.clients.centaur;

/**
 *
 * @author johne
 */
public enum ControlCharacters {

    SOH((char) 1),
    STX((char) 2),
    ETX((char) 3),
    EOT((char) 4),
    ENQ((char) 5),
    ACK((char) 6),
    LF((char) 10),
    CR((char) 13);

    private final Character ch;

    private ControlCharacters(Character ch) {
        this.ch = ch;
    }

    public Character getCharacter() {
        return ch;
    }

    public String getCharacterAsString() {
        return ch.toString();
    }

    public static ControlCharacters byValue(int val) {
        for (ControlCharacters chs : values()) {
            if (chs.getCharacter().equals((char) val)) {
                return chs;
            }
        }

        throw new IllegalStateException(String.format("Unknown control character: %d", val));
    }
}
