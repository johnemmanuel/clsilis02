package com.qdx.instruments.clients.centaur.tcp;

public enum TcpClientState {
    IDLE,
    RECEIVING,
    PROCESSING,
    SENDING
}
