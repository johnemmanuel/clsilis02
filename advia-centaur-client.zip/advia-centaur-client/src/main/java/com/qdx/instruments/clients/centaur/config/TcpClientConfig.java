package com.qdx.instruments.clients.centaur.config;

import com.qdx.instruments.clients.centaur.tcp.TcpClientHandler;
import com.qdx.instruments.clients.centaur.tcp.AstmCodecFactory;
import java.util.concurrent.Executors;
import org.apache.mina.core.service.IoConnector;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.executor.ExecutorFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author johne
 */
@Configuration
public class TcpClientConfig {

    @Bean
    public IoConnector ioConnector() {
        NioSocketConnector connector = new NioSocketConnector();
        connector.setHandler(new TcpClientHandler());
        connector.getFilterChain().addLast("codec", new ProtocolCodecFilter(new AstmCodecFactory()));
        connector.getFilterChain().addLast("executor", new ExecutorFilter(Executors.newCachedThreadPool()));
        connector.setConnectTimeoutMillis(30000); // Set connection timeout
        return connector;
    }
}
