package com.qdx.instruments.clients.centaur.tcp;

import java.net.InetSocketAddress;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.service.IoConnector;
import org.springframework.stereotype.Service;

@Service
public class TcpClientService {

    private final IoConnector ioConnector;

    public TcpClientService(IoConnector ioConnector) {
        this.ioConnector = ioConnector;
    }

    public void start(String host, int port) {
        try {
            ConnectFuture future = ioConnector.connect(new InetSocketAddress(host, port));
            future.awaitUninterruptibly();
            if (future.isConnected()) {
                System.out.println("Connected to the instrument at " + host + ":" + port);
            } else {
                System.out.println("Failed to connect to the instrument at " + host + ":" + port);
            }
        } catch (Exception e) {
            System.err.println("Error during connection: " + e.getMessage());
        }
    }

    public void stop() {
        ioConnector.dispose();
        System.out.println("Connection closed");
    }
}
