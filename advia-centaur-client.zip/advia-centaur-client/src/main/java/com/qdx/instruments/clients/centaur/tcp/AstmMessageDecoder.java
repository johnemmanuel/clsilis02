package com.qdx.instruments.clients.centaur.tcp;

import java.util.Arrays;

public class AstmMessageDecoder {

    public void decodeAstmResultMessage(String message) {
        String[] records = message.split("\\\\r"); // ASTM records are typically separated by carriage return

        for (String record : records) {
            char recordType = record.charAt(0);

            switch (recordType) {
                case 'H':
                    processHeaderRecord(record);
                    break;
                case 'P':
                    processPatientRecord(record);
                    break;
                case 'O':
                    processOrderRecord(record);
                    break;
                case 'R':
                    processResultRecord(record);
                    break;
                default:
                    System.out.println("Unknown record type: " + record);
                    break;
            }
        }
    }

    private void processHeaderRecord(String record) {
        String[] fields = record.split("\\\\|");
        System.out.println("Header Record: " + Arrays.toString(fields));
    }

    private void processPatientRecord(String record) {
        String[] fields = record.split("\\\\|");
        System.out.println("Patient Record: " + Arrays.toString(fields));
    }

    private void processOrderRecord(String record) {
        String[] fields = record.split("\\\\|");
        System.out.println("Order Record: " + Arrays.toString(fields));
    }

    private void processResultRecord(String record) {
        String[] fields = record.split("\\\\|");
        System.out.println("Result Record: " + Arrays.toString(fields));
    }
}
