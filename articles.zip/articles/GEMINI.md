# Article on Agent Skills

## Overview

I've been tasked with writing an article on Agent Skills.

## Audience

The audience for the article is anybody who uses an agent today. They can be technical folk such as developers, architects, program managers, project managers, business analysts, or non-technical folk such as accountants, financial analysts, writers, HR executives etc. Anybody who wants to understand and use Agents better is a target for this article. As such the language must be simple and easily understood by any one who reads it. Technical terminology if used must be explained so everyone understands.

## Article Structure

Here's the structure I am thinking of. Please let me know if I should be adding any other sections. 

Introduction
What are Agent Skills
How can you use them
Usecases and how you can leverage them
How do you create a Skill and what elements do you need to package it
What are the things you need to consider to ensure the skill is effective (if your scripts are in python everybody needs to have python installed)
Are Agent Skills local or can we use them on the server-side too. If yes, How
How do you deploy agent Skills
How do skills differ across Agent environments (Claude, OpenCode, OpenAI etc)
Example of a skill and how it can be developed step by step
Conclusion
Appendix
- References
- Online articles

## Document Format

I would like to have the document in Asciidoc Article format. Structure the document with proper headings, sub-headings and sections that explain and illustrate the subject in the simplest and easily understandable language. Since this is an article on a technical subject I understand we may have to use technical words and jargon. But please limit this to barest possible minimum. We want the article to be original and understood by everybody technical and non-technical.

Use images where possible and where a diagram will help understanding better. All images must be original and generated in mermaid or drawio diagrams which after rendering to PNG or JPEG can be include in the diagrams. Having the originals in mermaid and drawio allow for changes and updates.

