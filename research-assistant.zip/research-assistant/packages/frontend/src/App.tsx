import { useState, useEffect } from 'react';
import { 
  Sparkles, Search, Globe, ShieldAlert, Cpu, ArrowRight, ArrowLeft, 
  Trash2, Plus, Check, Settings, X, FileText, Download, CheckCircle2,
  ListTodo, Loader2
} from 'lucide-react';

// Types matching backend API
interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

interface ScrapedPage {
  url: string;
  title: string;
  excerpt: string;
  siteName: string;
  confidenceScore: 'high' | 'medium' | 'low';
  confidenceRationale: string;
}

interface ScrapedResult {
  page: ScrapedPage;
  facts: Record<string, any>;
}

export default function App() {
  // Navigation & Workflow Steps
  // Steps: 'define' | 'refine' | 'select' | 'export' | 'automated-running' | 'automated-finished'
  const [step, setStep] = useState<'define' | 'refine' | 'select' | 'export' | 'automated-running' | 'automated-finished'>('define');
  
  // Settings Drawer (localStorage configuration)
  const [showSettings, setShowSettings] = useState(false);
  const [geminiKey, setGeminiKey] = useState('');
  const [anthropicKey, setAnthropicKey] = useState('');
  const [googleKey, setGoogleKey] = useState('');
  const [googleCx, setGoogleCx] = useState('');

  // Step 1: Define Query State
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState<'gemini' | 'claude'>('gemini');
  const [searchEngine, setSearchEngine] = useState<'duckduckgo' | 'google'>('duckduckgo');
  const [automated, setAutomated] = useState(false);
  const [maxAutoLinks, setMaxAutoLinks] = useState(3);

  // Step 2: Refine Plan State
  const [searchTerms, setSearchTerms] = useState<string[]>([]);
  const [newTerm, setNewTerm] = useState('');
  const [dataPoints, setDataPoints] = useState<{ key: string; description: string; type: 'string' | 'number' | 'boolean' | 'array' }[]>([]);
  const [newDataPoint, setNewDataPoint] = useState({ key: '', description: '', type: 'string' as const });

  // Step 3: Select Results State
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [selectedUrls, setSelectedUrls] = useState<string[]>([]);
  const [customUrl, setCustomUrl] = useState('');

  // Step 4: Preview & Export State
  const [scrapedResults, setScrapedResults] = useState<ScrapedResult[]>([]);
  const [exportFormat, setExportFormat] = useState<'article' | 'comparison' | 'summary'>('article');
  const [exportType, setExportType] = useState<'markdown' | 'word' | 'pdf'>('markdown');
  const [exportName, setExportName] = useState('');
  const [synthesizedPreview, setSynthesizedPreview] = useState('');
  const [exportedFilePath, setExportedFilePath] = useState('');

  // Running Logs for Automated Flow
  const [logs, setLogs] = useState<string[]>([]);

  // Local API Key loading
  useEffect(() => {
    setGeminiKey(localStorage.getItem('gemini_key') || '');
    setAnthropicKey(localStorage.getItem('anthropic_key') || '');
    setGoogleKey(localStorage.getItem('google_key') || '');
    setGoogleCx(localStorage.getItem('google_cx') || '');
  }, []);

  const saveSettings = () => {
    localStorage.setItem('gemini_key', geminiKey);
    localStorage.setItem('anthropic_key', anthropicKey);
    localStorage.setItem('google_key', googleKey);
    localStorage.setItem('google_cx', googleCx);
    setShowSettings(false);
  };

  const addLog = (message: string) => {
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
  };

  // ============================================
  // WORKFLOW PIPELINE EXECUTIONS
  // ============================================

  // 1. Prompt analysis (Define -> Refine)
  const handleAnalyzePrompt = async () => {
    if (!prompt) return alert('Please enter a prompt describing your research topic.');
    
    // Check key requirements
    if (model === 'gemini' && !geminiKey) {
      alert('Please configure your Gemini API Key in the settings panel (top right gear icon).');
      setShowSettings(true);
      return;
    }
    if (model === 'claude' && !anthropicKey) {
      alert('Please configure your Anthropic API Key in the settings panel (top right gear icon).');
      setShowSettings(true);
      return;
    }

    if (automated) {
      // Execute Fully Automated Pipeline
      setStep('automated-running');
      setLogs([]);
      try {
        addLog('Initializing research agent...');
        addLog(`Analyzing request: "${prompt}" using ${model}...`);
        
        const planRes = await fetch('http://localhost:3001/api/analyze-prompt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, model, geminiApiKey: geminiKey, anthropicApiKey: anthropicKey })
        });
        const plan = await planRes.json();
        if (plan.error) throw new Error(plan.error);
        
        addLog(`Plan generated. Inferred search terms: ${plan.searchTerms.join(', ')}`);
        addLog(`Inferred extraction schema: ${plan.dataPoints.map((d: any) => d.key).join(', ')}`);

        // Execute searches
        addLog('Firing web search queries in parallel...');
        const allSearchResults: SearchResult[] = [];
        for (const term of plan.searchTerms) {
          addLog(`Searching DuckDuckGo for: "${term}"...`);
          const searchRes = await fetch('http://localhost:3001/api/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: term, engine: searchEngine, googleApiKey: googleKey, googleCx })
          });
          const results = await searchRes.json();
          if (!results.error) {
            allSearchResults.push(...results);
          }
        }

        // Deduplicate search results
        const uniqueResults = allSearchResults.filter(
          (item, index, self) => index === self.findIndex((t) => t.url === item.url)
        );
        addLog(`Web search resolved. Gathered ${uniqueResults.length} unique sources.`);

        // Scrape top links
        addLog(`Selecting the top ${maxAutoLinks} links to scrape...`);
        const linksToScrape = uniqueResults.slice(0, maxAutoLinks);
        const scrapings: ScrapedResult[] = [];

        for (let i = 0; i < linksToScrape.length; i++) {
          const target = linksToScrape[i];
          addLog(`[Scraper ${i+1}/${linksToScrape.length}] Loading page & bypassing Cloudflare: ${target.url}...`);
          try {
            const scrapeRes = await fetch('http://localhost:3001/api/scrape-and-extract', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                url: target.url,
                searchTerms: plan.searchTerms,
                dataPoints: plan.dataPoints,
                model,
                geminiApiKey: geminiKey,
                anthropicApiKey: anthropicKey
              })
            });
            const data = await scrapeRes.json();
            if (!data.error) {
              scrapings.push(data);
              addLog(`[Scraper ${i+1}/${linksToScrape.length}] Scraped successfully! Core article isolated. AI Relevance: ${data.page.confidenceScore.toUpperCase()}`);
            } else {
              addLog(`[Scraper ${i+1}/${linksToScrape.length}] Failed to scrape: ${data.error}`);
            }
          } catch (e: any) {
            addLog(`[Scraper ${i+1}/${linksToScrape.length}] Failed to scrape: ${e.message}`);
          }
        }

        if (scrapings.length === 0) {
          throw new Error('All target web scrapings failed. Cannot compile report.');
        }

        // Synthesize and Export
        addLog('Synthesizing research data and writing finalized report...');
        const exportRes = await fetch('http://localhost:3001/api/export', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            extractedFacts: scrapings.map(s => s.facts),
            format: 'article',
            formatType: 'markdown',
            fileName: `automated_research_${Date.now()}`,
            model,
            geminiApiKey: geminiKey,
            anthropicApiKey: anthropicKey
          })
        });
        const finalReport = await exportRes.json();
        if (finalReport.error) throw new Error(finalReport.error);

        setSynthesizedPreview(finalReport.preview);
        setExportedFilePath(finalReport.filePath);
        setStep('automated-finished');
        addLog('Report synthesized and saved! Pipeline complete.');

      } catch (err: any) {
        addLog(`CRITICAL PIPELINE FAILURE: ${err.message}`);
        setStep('define');
        alert(`Research Pipeline Failed: ${err.message}`);
      }
    } else {
      // Human-in-the-Loop flow
      setStep('automated-running');
      try {
        const planRes = await fetch('http://localhost:3001/api/analyze-prompt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, model, geminiApiKey: geminiKey, anthropicApiKey: anthropicKey })
        });
        const plan = await planRes.json();
        if (plan.error) throw new Error(plan.error);

        setSearchTerms(plan.searchTerms);
        setDataPoints(plan.dataPoints);
        setStep('refine');
      } catch (err: any) {
        setStep('define');
        alert(`Failed to analyze prompt: ${err.message}`);
      }
    }
  };

  // 2. Refine search terms and data points (Refine -> Select Links)
  const handleExecuteSearch = async () => {
    if (searchTerms.length === 0) return alert('Please enter at least one search query.');
    setStep('automated-running');
    try {
      const allSearchResults: SearchResult[] = [];
      for (const term of searchTerms) {
        const searchRes = await fetch('http://localhost:3001/api/search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: term, engine: searchEngine, googleApiKey: googleKey, googleCx })
        });
        const results = await searchRes.json();
        if (!results.error) {
          allSearchResults.push(...results);
        }
      }

      // Deduplicate results
      const uniqueResults = allSearchResults.filter(
        (item, index, self) => index === self.findIndex((t) => t.url === item.url)
      );

      setSearchResults(uniqueResults);
      // Pre-select top 3 links as default selections
      setSelectedUrls(uniqueResults.slice(0, 3).map(r => r.url));
      setStep('select');
    } catch (err: any) {
      setStep('refine');
      alert(`Search queries failed: ${err.message}`);
    }
  };

  // 3. Scrape pages & extract facts (Select Links -> Export/Preview)
  const handleScrapeAndExtract = async () => {
    if (selectedUrls.length === 0) return alert('Please select at least one link to scrape.');
    setStep('automated-running');
    try {
      const results: ScrapedResult[] = [];
      for (const url of selectedUrls) {
        const scrapeRes = await fetch('http://localhost:3001/api/scrape-and-extract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            url,
            searchTerms,
            dataPoints,
            model,
            geminiApiKey: geminiKey,
            anthropicApiKey: anthropicKey
          })
        });
        const data = await scrapeRes.json();
        if (!data.error) {
          results.push(data);
        }
      }

      if (results.length === 0) {
        throw new Error('All webpage scrapings failed. Please check the URLs and try again.');
      }

      setScrapedResults(results);
      setExportName(`research_report_${Date.now()}`);
      setStep('export');
    } catch (err: any) {
      setStep('select');
      alert(`Scraping failed: ${err.message}`);
    }
  };

  // 4. Save and Export report directly to workspace
  const handleCompileAndExport = async () => {
    setStep('automated-running');
    try {
      const exportRes = await fetch('http://localhost:3001/api/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          extractedFacts: scrapedResults.map(r => r.facts),
          format: exportFormat,
          formatType: exportType,
          fileName: exportName || `research_report_${Date.now()}`,
          model,
          geminiApiKey: geminiKey,
          anthropicApiKey: anthropicKey
        })
      });
      const data = await exportRes.json();
      if (data.error) throw new Error(data.error);

      setSynthesizedPreview(data.preview);
      setExportedFilePath(data.filePath);
      setStep('automated-finished');
    } catch (err: any) {
      setStep('export');
      alert(`Failed to save report: ${err.message}`);
    }
  };

  // ============================================
  // FRONTEND STEP VIEWS
  // ============================================

  return (
    <div className="min-h-screen bg-bg-primary text-slate-200 flex flex-col font-sans antialiased relative selection:bg-accent-indigo/30 selection:text-white">
      {/* Immersive Glass Background Blur elements */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent-indigo/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent-violet/5 rounded-full blur-3xl pointer-events-none" />

      {/* Navigation Header */}
      <header className="glass-panel border-b border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-accent-indigo/10 border border-accent-indigo/20">
            <Sparkles className="w-5 h-5 text-accent-indigo" />
          </div>
          <span className="font-heading text-xl font-bold tracking-tight text-gradient">
            Research Assistant
          </span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-accent-emerald/10 border border-accent-emerald/20 text-accent-emerald text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-accent-emerald animate-pulse" />
            Bun Host Connected
          </div>
          <button 
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 rounded-xl border border-white/5 hover:border-white/10 bg-bg-secondary hover:bg-bg-tertiary transition-all cursor-pointer text-slate-400 hover:text-slate-100"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* API Credentials Drawer */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex justify-end">
          <div className="w-full max-w-md bg-bg-secondary border-l border-white/10 p-6 flex flex-col gap-6 h-full shadow-2xl">
            <div className="flex items-center justify-between">
              <span className="font-heading text-lg font-bold text-slate-100 flex items-center gap-2">
                <Settings className="w-5 h-5 text-accent-indigo" /> Configure Credentials
              </span>
              <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-100 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed border-b border-white/5 pb-4">
              Your API keys are stored safely inside your local browser's storage and are only sent directly to your local Bun backend for requests.
            </p>

            <div className="flex flex-col gap-4 flex-1 overflow-y-auto pr-2">
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-400 tracking-wider">GEMINI API KEY</label>
                <input
                  type="password"
                  value={geminiKey}
                  onChange={(e) => setGeminiKey(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full bg-bg-primary border border-white/5 rounded-xl p-3 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-accent-indigo/50 text-sm"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold text-slate-400 tracking-wider">ANTHROPIC API KEY</label>
                <input
                  type="password"
                  value={anthropicKey}
                  onChange={(e) => setAnthropicKey(e.target.value)}
                  placeholder="sk-ant-..."
                  className="w-full bg-bg-primary border border-white/5 rounded-xl p-3 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-accent-indigo/50 text-sm"
                />
              </div>

              <div className="border-t border-white/5 my-2 pt-4">
                <h4 className="text-xs font-bold text-slate-200 mb-2 flex items-center gap-1.5">
                  <Search className="w-4 h-4 text-accent-violet" /> Google Custom Search (Optional)
                </h4>
                <div className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold text-slate-400 tracking-wider">GOOGLE SEARCH API KEY</label>
                    <input
                      type="password"
                      value={googleKey}
                      onChange={(e) => setGoogleKey(e.target.value)}
                      placeholder="AIzaSyGoogleSearch..."
                      className="w-full bg-bg-primary border border-white/5 rounded-xl p-3 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-accent-violet/50 text-sm"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-[10px] font-bold text-slate-400 tracking-wider">SEARCH ENGINE CX ID</label>
                    <input
                      type="text"
                      value={googleCx}
                      onChange={(e) => setGoogleCx(e.target.value)}
                      placeholder="cx-id-format-example"
                      className="w-full bg-bg-primary border border-white/5 rounded-xl p-3 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-accent-violet/50 text-sm"
                    />
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={saveSettings}
              className="w-full py-3 rounded-xl font-heading font-bold text-sm btn-gradient text-white flex items-center justify-center gap-2 cursor-pointer"
            >
              <Check className="w-4 h-4" /> Save Local Settings
            </button>
          </div>
        </div>
      )}

      {/* Main Content Layout */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-6 md:p-10 flex flex-col gap-8">
        
        {/* Step Progress Stepper (Visible in HITL flow) */}
        {step !== 'automated-running' && step !== 'automated-finished' && (
          <div className="glass-panel rounded-full px-6 py-3 flex justify-between items-center text-xs font-semibold text-slate-500 overflow-x-auto gap-4">
            <div className={`flex items-center gap-2 shrink-0 ${step === 'define' ? 'text-accent-indigo font-bold' : ''}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${step === 'define' ? 'border-accent-indigo bg-accent-indigo/10 text-accent-indigo' : 'border-white/10'}`}>1</span> Define
            </div>
            <ArrowRight className="w-4 h-4 text-slate-700 shrink-0" />
            <div className={`flex items-center gap-2 shrink-0 ${step === 'refine' ? 'text-accent-violet font-bold' : ''}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${step === 'refine' ? 'border-accent-violet bg-accent-violet/10 text-accent-violet' : 'border-white/10'}`}>2</span> Refine terms
            </div>
            <ArrowRight className="w-4 h-4 text-slate-700 shrink-0" />
            <div className={`flex items-center gap-2 shrink-0 ${step === 'select' ? 'text-accent-emerald font-bold' : ''}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${step === 'select' ? 'border-accent-emerald bg-accent-emerald/10 text-accent-emerald' : 'border-white/10'}`}>3</span> Select Links
            </div>
            <ArrowRight className="w-4 h-4 text-slate-700 shrink-0" />
            <div className={`flex items-center gap-2 shrink-0 ${step === 'export' ? 'text-accent-amber font-bold' : ''}`}>
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${step === 'export' ? 'border-accent-amber bg-accent-amber/10 text-accent-amber' : 'border-white/10'}`}>4</span> Synthesize
            </div>
          </div>
        )}

        {/* ============================================
            STEP VIEW 1: DEFINE QUERY
           ============================================ */}
        {step === 'define' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            <div className="flex flex-col gap-2 max-w-2xl">
              <h1 className="font-heading text-4xl font-extrabold tracking-tight text-gradient leading-tight">
                Deep Research Assistant
              </h1>
              <p className="text-slate-400 text-sm">
                Analyze a research topic, isolate primary clean text from modern sites using residential-stealth scraping, and compile structured reports.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Query Panel */}
              <div className="lg:col-span-2 glass-panel rounded-2xl p-6 md:p-8 flex flex-col gap-6">
                <div className="flex items-center justify-between text-sm font-heading font-bold text-accent-indigo">
                  <span className="flex items-center gap-2"><Globe className="w-4 h-4" /> STEP 1: CONFIGURE RESEARCH QUERY</span>
                </div>

                <div className="flex flex-col gap-2">
                  <label htmlFor="prompt-input" className="text-[10px] font-bold text-slate-400 tracking-wider">
                    ENTER WHAT YOU WISH TO STUDY
                  </label>
                  <textarea
                    id="prompt-input"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Example: Study the latest 2026 solid-state battery energy density commercial metrics, pilot plant capacities, and manufacturing hurdles..."
                    className="w-full h-36 bg-bg-secondary border border-white/5 rounded-xl p-4 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-accent-indigo/50 transition-colors text-sm resize-none"
                  />
                </div>

                <button
                  onClick={handleAnalyzePrompt}
                  className="w-full py-4 rounded-xl font-heading font-bold text-sm btn-gradient text-white flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-accent-indigo/15"
                >
                  Analyze & Start Research Plan <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Properties Panel */}
              <div className="glass-panel rounded-2xl p-6 flex flex-col gap-6">
                <div className="flex items-center gap-2 text-sm font-heading font-bold text-accent-violet border-b border-white/5 pb-4">
                  <Cpu className="w-4 h-4" /> AGENT PROPERTIES
                </div>

                {/* AI Model */}
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider">AI AGENT ENGINE</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setModel('gemini')}
                      className={`py-2 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        model === 'gemini'
                          ? 'border-accent-indigo bg-accent-indigo/10 text-accent-indigo font-black'
                          : 'border-white/5 bg-bg-secondary text-slate-500 hover:border-white/10'
                      }`}
                    >
                      Gemini Pro
                    </button>
                    <button
                      onClick={() => setModel('claude')}
                      className={`py-2 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        model === 'claude'
                          ? 'border-accent-violet bg-accent-violet/10 text-accent-violet font-black'
                          : 'border-white/5 bg-bg-secondary text-slate-500 hover:border-white/10'
                      }`}
                    >
                      Claude Sonnet
                    </button>
                  </div>
                </div>

                {/* Search Engine */}
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider">WEB SEARCH SYSTEM</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSearchEngine('duckduckgo')}
                      className={`py-2 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        searchEngine === 'duckduckgo'
                          ? 'border-accent-indigo bg-accent-indigo/10 text-accent-indigo font-black'
                          : 'border-white/5 bg-bg-secondary text-slate-500 hover:border-white/10'
                      }`}
                    >
                      DuckDuckGo
                    </button>
                    <button
                      onClick={() => setSearchEngine('google')}
                      className={`py-2 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        searchEngine === 'google'
                          ? 'border-accent-violet bg-accent-violet/10 text-accent-violet font-black'
                          : 'border-white/5 bg-bg-secondary text-slate-500 hover:border-white/10'
                      }`}
                    >
                      Google CSE
                    </button>
                  </div>
                </div>

                {/* Automation Strategy */}
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider">WORKFLOW STRATEGY</span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setAutomated(false)}
                      className={`py-2 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        !automated
                          ? 'border-accent-emerald bg-accent-emerald/10 text-accent-emerald font-black'
                          : 'border-white/5 bg-bg-secondary text-slate-500 hover:border-white/10'
                      }`}
                    >
                      Human-In-Loop
                    </button>
                    <button
                      onClick={() => setAutomated(true)}
                      className={`py-2 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                        automated
                          ? 'border-accent-amber bg-accent-amber/10 text-accent-amber font-black'
                          : 'border-white/5 bg-bg-secondary text-slate-500 hover:border-white/10'
                      }`}
                    >
                      Fully Automated
                    </button>
                  </div>
                </div>

                {automated && (
                  <div className="flex flex-col gap-1.5 animate-fadeIn">
                    <label className="text-[10px] font-bold text-slate-400 tracking-wider">MAX LINKS TO AUTO-SCRAPE</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={maxAutoLinks}
                      onChange={(e) => setMaxAutoLinks(parseInt(e.target.value) || 3)}
                      className="w-full bg-bg-secondary border border-white/5 rounded-lg p-2 text-slate-200 text-xs focus:outline-none focus:border-accent-amber/50"
                    />
                  </div>
                )}

                {/* Guard Note */}
                <div className="mt-auto p-3.5 rounded-xl bg-slate-500/5 border border-white/5 flex gap-3 items-start">
                  <ShieldAlert className="w-4 h-4 text-accent-slate shrink-0 mt-0.5" />
                  <div className="flex flex-col gap-0.5 text-[10px] text-slate-400 leading-normal">
                    <span className="font-bold text-slate-200">Residential Stealth Engine Active</span>
                    Playwright runs on your residential IP, securing Cloudflare bypass on 99% of targets for 100% free.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============================================
            STEP VIEW 2: REFINE PLAN
           ============================================ */}
        {step === 'refine' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            <div className="flex items-center gap-3">
              <button onClick={() => setStep('define')} className="p-2 rounded-lg border border-white/5 bg-bg-secondary hover:bg-bg-tertiary transition-all cursor-pointer text-slate-400 hover:text-slate-100">
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="font-heading text-2xl font-black text-gradient">Step 2: Refine Search Plan & Data Schema</h2>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Search Terms Refining */}
              <div className="glass-panel rounded-2xl p-6 flex flex-col gap-6">
                <h3 className="text-sm font-heading font-bold text-accent-indigo flex items-center gap-2">
                  <Search className="w-4 h-4" /> REFINE INFERRED WEB QUERIES
                </h3>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  These search terms were generated by AI to explore your topic. Review, add, or remove terms to ensure we find target contents.
                </p>

                {/* Terms List */}
                <div className="flex flex-wrap gap-2 pr-2">
                  {searchTerms.map((term, index) => (
                    <div key={index} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-bg-secondary border border-white/10 text-xs font-semibold text-slate-200 hover:border-accent-indigo/50 transition-colors">
                      {term}
                      <button 
                        onClick={() => setSearchTerms(searchTerms.filter((_, idx) => idx !== index))}
                        className="text-slate-500 hover:text-red-400 cursor-pointer transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Add Term */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newTerm}
                    onChange={(e) => setNewTerm(e.target.value)}
                    placeholder="Enter custom search term..."
                    className="flex-1 bg-bg-secondary border border-white/5 rounded-xl px-4 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-accent-indigo/50"
                  />
                  <button
                    onClick={() => {
                      if (newTerm.trim()) {
                        setSearchTerms([...searchTerms, newTerm.trim()]);
                        setNewTerm('');
                      }
                    }}
                    className="p-3 rounded-xl btn-gradient text-white cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Data Points Schema Refining */}
              <div className="glass-panel rounded-2xl p-6 flex flex-col gap-6">
                <h3 className="text-sm font-heading font-bold text-accent-violet flex items-center gap-2">
                  <ListTodo className="w-4 h-4" /> REFINE DATA EXTRACTION PLAN
                </h3>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Define the structured data points you want the AI to extract from each scraped page.
                </p>

                {/* Data Points List */}
                <div className="flex flex-col gap-2 max-h-60 overflow-y-auto pr-2">
                  {dataPoints.map((point, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-xl bg-bg-secondary border border-white/5 text-xs">
                      <div className="flex flex-col gap-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-accent-violet">{point.key}</span>
                          <span className="px-1.5 py-0.5 rounded bg-white/5 text-[9px] font-semibold text-slate-500 uppercase">{point.type}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 leading-relaxed">{point.description}</span>
                      </div>
                      <button 
                        onClick={() => setDataPoints(dataPoints.filter((_, idx) => idx !== index))}
                        className="p-2 text-slate-500 hover:text-red-400 cursor-pointer transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Add Data Point */}
                <div className="flex flex-col gap-3 border-t border-white/5 pt-4">
                  <span className="text-[10px] font-bold text-slate-400 tracking-wider">ADD CUSTOM DATA POINT</span>
                  <div className="grid grid-cols-3 gap-2">
                    <input
                      type="text"
                      placeholder="key (camelCase)"
                      value={newDataPoint.key}
                      onChange={(e) => setNewDataPoint({ ...newDataPoint, key: e.target.value })}
                      className="bg-bg-secondary border border-white/5 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:border-accent-violet/50"
                    />
                    <input
                      type="text"
                      placeholder="Description"
                      value={newDataPoint.description}
                      onChange={(e) => setNewDataPoint({ ...newDataPoint, description: e.target.value })}
                      className="bg-bg-secondary border border-white/5 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:border-accent-violet/50"
                    />
                    <select
                      value={newDataPoint.type}
                      onChange={(e: any) => setNewDataPoint({ ...newDataPoint, type: e.target.value })}
                      className="bg-bg-secondary border border-white/5 rounded-xl px-2 py-2.5 text-xs focus:outline-none focus:border-accent-violet/50 text-slate-400"
                    >
                      <option value="string">string</option>
                      <option value="number">number</option>
                      <option value="boolean">boolean</option>
                      <option value="array">array</option>
                    </select>
                  </div>
                  <button
                    onClick={() => {
                      if (newDataPoint.key && newDataPoint.description) {
                        setDataPoints([...dataPoints, newDataPoint]);
                        setNewDataPoint({ key: '', description: '', type: 'string' });
                      }
                    }}
                    className="py-2.5 rounded-xl border border-accent-violet/20 hover:border-accent-violet/50 bg-accent-violet/5 text-accent-violet font-bold text-xs cursor-pointer text-center"
                  >
                    Add Schema Data Element
                  </button>
                </div>
              </div>

            </div>

            {/* Run Button */}
            <button
              onClick={handleExecuteSearch}
              className="w-full py-4 rounded-xl font-heading font-bold text-sm btn-gradient text-white flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-accent-indigo/15"
            >
              Fulfill Queries & Search the Web <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* ============================================
            STEP VIEW 3: SELECT RESULTS
           ============================================ */}
        {step === 'select' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            <div className="flex items-center gap-3">
              <button onClick={() => setStep('refine')} className="p-2 rounded-lg border border-white/5 bg-bg-secondary hover:bg-bg-tertiary transition-all cursor-pointer text-slate-400 hover:text-slate-100">
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="font-heading text-2xl font-black text-gradient">Step 3: Select Intelligence Sources</h2>
            </div>

            {/* Search Results Display */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Left Column: Search Result List */}
              <div className="lg:col-span-2 flex flex-col gap-4">
                <h3 className="text-xs font-bold text-slate-400 tracking-wider">WEB SEARCH FINDINGS</h3>
                <div className="flex flex-col gap-3 max-h-[500px] overflow-y-auto pr-2">
                  {searchResults.map((result, idx) => {
                    const isSelected = selectedUrls.includes(result.url);
                    const domain = new URL(result.url).hostname;
                    return (
                      <div 
                        key={idx}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedUrls(selectedUrls.filter(u => u !== result.url));
                          } else {
                            setSelectedUrls([...selectedUrls, result.url]);
                          }
                        }}
                        className={`p-4 rounded-xl border transition-all cursor-pointer flex gap-4 ${
                          isSelected 
                            ? 'border-accent-emerald/40 bg-accent-emerald/5' 
                            : 'border-white/5 bg-bg-secondary hover:border-white/10'
                        }`}
                      >
                        <div className="flex items-start shrink-0 pt-0.5">
                          <div className={`w-5 h-5 rounded-lg border flex items-center justify-center ${isSelected ? 'border-accent-emerald bg-accent-emerald text-white' : 'border-white/10'}`}>
                            {isSelected && <Check className="w-3.5 h-3.5" />}
                          </div>
                        </div>

                        <div className="flex flex-col gap-1.5">
                          <span className="font-heading text-sm font-bold text-slate-100 leading-tight">
                            {result.title}
                          </span>
                          <span className="text-[10px] text-accent-indigo font-semibold tracking-wide flex items-center gap-1.5">
                            <Globe className="w-3 h-3" /> {domain}
                          </span>
                          <p className="text-xs text-slate-400 leading-normal line-clamp-2">
                            {result.snippet}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Column: Custom URL Add & Trigger */}
              <div className="glass-panel rounded-2xl p-6 flex flex-col gap-6">
                <h3 className="text-sm font-heading font-bold text-accent-violet">SELECTIONS SUMMARY</h3>
                
                <div className="p-4 rounded-xl bg-bg-secondary border border-white/5 flex flex-col gap-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Selected Links:</span>
                    <span className="font-bold text-accent-emerald">{selectedUrls.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">AI Relevance Confidence:</span>
                    <span className="font-bold text-slate-300">Prerelease (Home IP Enabled)</span>
                  </div>
                </div>

                {/* Add Custom Link */}
                <div className="flex flex-col gap-2 border-t border-white/5 pt-4">
                  <label className="text-[10px] font-bold text-slate-400 tracking-wider">ADD A CUSTOM URL</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customUrl}
                      onChange={(e) => setCustomUrl(e.target.value)}
                      placeholder="https://example.com/article"
                      className="flex-1 bg-bg-secondary border border-white/5 rounded-xl px-4 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-accent-violet/50"
                    />
                    <button
                      onClick={() => {
                        if (customUrl.trim()) {
                          try {
                            new URL(customUrl.trim());
                            setSelectedUrls([...selectedUrls, customUrl.trim()]);
                            setSearchResults([{ title: 'Custom Supplied Link', url: customUrl.trim(), snippet: 'Manually loaded custom URL.' }, ...searchResults]);
                            setCustomUrl('');
                          } catch (e) {
                            alert('Please enter a valid HTTP/HTTPS URL.');
                          }
                        }
                      }}
                      className="p-3 rounded-xl btn-gradient text-white cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <button
                  onClick={handleScrapeAndExtract}
                  className="w-full py-4 rounded-xl font-heading font-bold text-sm btn-gradient text-white flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-accent-indigo/15 mt-auto"
                >
                  Scrape & Extract Web Content <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          </div>
        )}

        {/* ============================================
            STEP VIEW 4: EXPORT REPORT
           ============================================ */}
        {step === 'export' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            <div className="flex items-center gap-3">
              <button onClick={() => setStep('select')} className="p-2 rounded-lg border border-white/5 bg-bg-secondary hover:bg-bg-tertiary transition-all cursor-pointer text-slate-400 hover:text-slate-100">
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h2 className="font-heading text-2xl font-black text-gradient">Step 4: Compile & Save Final Report</h2>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Left Column: Extracted Facts Viewer */}
              <div className="lg:col-span-2 flex flex-col gap-4">
                <h3 className="text-xs font-bold text-slate-400 tracking-wider">EXTRACTED STRUCTURED FACTS</h3>
                <div className="flex flex-col gap-4 max-h-[500px] overflow-y-auto pr-2">
                  {scrapedResults.map((result, idx) => (
                    <div key={idx} className="glass-panel rounded-2xl p-6 flex flex-col gap-4">
                      <div className="flex items-center justify-between border-b border-white/5 pb-3">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-heading text-sm font-bold text-slate-100">{result.page.title}</span>
                          <span className="text-[10px] text-accent-indigo font-semibold">{result.page.siteName}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          result.page.confidenceScore === 'high' 
                            ? 'bg-accent-emerald/10 border border-accent-emerald/20 text-accent-emerald' 
                            : result.page.confidenceScore === 'medium'
                            ? 'bg-accent-amber/10 border border-accent-amber/20 text-accent-amber'
                            : 'bg-accent-slate/10 border border-accent-slate/20 text-accent-slate'
                        }`}>
                          {result.page.confidenceScore} Relevance
                        </span>
                      </div>

                      {/* JSON viewer */}
                      <pre className="p-4 bg-bg-secondary border border-white/5 rounded-xl text-[11px] text-accent-indigo overflow-x-auto font-mono max-h-48">
                        {JSON.stringify(result.facts, null, 2)}
                      </pre>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Export Format Panel */}
              <div className="glass-panel rounded-2xl p-6 flex flex-col gap-6">
                <h3 className="text-sm font-heading font-bold text-accent-violet">SYNTHESIS OPTIONS</h3>
                
                {/* Format layout style */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 tracking-wider">REPORT LAYOUT TEMPLATE</label>
                  <select
                    value={exportFormat}
                    onChange={(e: any) => setExportFormat(e.target.value)}
                    className="w-full bg-bg-secondary border border-white/5 rounded-xl p-3 text-slate-300 text-xs focus:outline-none focus:border-accent-violet/50"
                  >
                    <option value="article"> Narrative Deep-Dive Article</option>
                    <option value="comparison"> Structured Comparison Tables</option>
                    <option value="summary"> Concise Executive Summary</option>
                  </select>
                </div>

                {/* File export type */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 tracking-wider">EXPORT FILE FORMAT</label>
                  <select
                    value={exportType}
                    onChange={(e: any) => setExportType(e.target.value)}
                    className="w-full bg-bg-secondary border border-white/5 rounded-xl p-3 text-slate-300 text-xs focus:outline-none focus:border-accent-violet/50"
                  >
                    <option value="markdown">Markdown Document (.md)</option>
                    <option value="word">Native Microsoft Word (.docx)</option>
                    <option value="pdf">Standard PDF Document (.pdf)</option>
                  </select>
                </div>

                {/* File name */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold text-slate-400 tracking-wider">REPORT FILE NAME</label>
                  <input
                    type="text"
                    value={exportName}
                    onChange={(e) => setExportName(e.target.value)}
                    placeholder="Enter file name..."
                    className="w-full bg-bg-secondary border border-white/5 rounded-xl p-3 text-slate-300 text-xs focus:outline-none focus:border-accent-violet/50"
                  />
                </div>

                <button
                  onClick={handleCompileAndExport}
                  className="w-full py-4 rounded-xl font-heading font-bold text-sm btn-gradient text-white flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-accent-indigo/15 mt-auto"
                >
                  <Download className="w-4 h-4" /> Save Finalized Report to Workspace
                </button>
              </div>

            </div>
          </div>
        )}

        {/* ============================================
            STEP VIEW 5: AUTOMATED RUNNING PROGRESS LOG
           ============================================ */}
        {step === 'automated-running' && (
          <div className="glass-panel rounded-2xl p-6 md:p-10 flex flex-col items-center justify-center min-h-[400px] gap-6 animate-pulse select-none">
            <Loader2 className="w-12 h-12 text-accent-indigo animate-spin" />
            
            <div className="flex flex-col items-center gap-2 text-center max-w-md">
              <h3 className="font-heading text-lg font-bold text-slate-100">AI Research Agent Executing Pipeline</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Spawning local headless browsers, rotating user agents, bypassing bot detectors, and extracting structured data elements from targets.
              </p>
            </div>

            {/* Run logs */}
            {logs.length > 0 && (
              <div className="w-full max-w-2xl bg-[#030712] border border-white/5 p-4 rounded-xl font-mono text-[10px] text-accent-emerald flex flex-col gap-1 max-h-48 overflow-y-auto text-left shadow-inner">
                {logs.map((log, index) => (
                  <div key={index} className="leading-relaxed border-b border-white/5 py-0.5 last:border-b-0">
                    {log}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ============================================
            STEP VIEW 6: PIPELINE COMPLETED PREVIEW
           ============================================ */}
        {step === 'automated-finished' && (
          <div className="flex flex-col gap-8 animate-fadeIn">
            
            {/* Header success indicator */}
            <div className="glass-panel border-accent-emerald/30 bg-accent-emerald/5 rounded-2xl p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="w-10 h-10 text-accent-emerald shrink-0 mt-1" />
                <div className="flex flex-col gap-1">
                  <h2 className="font-heading text-xl font-black text-slate-100">Research Complete & Report Saved!</h2>
                  <p className="text-xs text-slate-400 leading-normal max-w-xl">
                    Finalized research syntheses successfully created and saved directly inside your workspace directory:
                    <span className="block font-mono bg-bg-secondary p-2 rounded border border-white/5 mt-1 text-[10px] text-slate-300 overflow-x-auto break-all">{exportedFilePath}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setPrompt('');
                  setSynthesizedPreview('');
                  setExportedFilePath('');
                  setStep('define');
                }}
                className="px-5 py-3 rounded-xl border border-white/5 bg-bg-secondary hover:bg-bg-tertiary text-slate-300 font-heading font-bold text-xs cursor-pointer transition-all self-end md:self-auto shrink-0 text-white"
              >
                Create New Research Query
              </button>
            </div>

            {/* Document Preview Panels */}
            <div className="glass-panel rounded-2xl p-6 md:p-8 flex flex-col gap-6">
              <h3 className="text-sm font-heading font-bold text-accent-indigo flex items-center gap-2 border-b border-white/5 pb-4">
                <FileText className="w-4 h-4" /> COMPILATION DOCUMENT PREVIEW
              </h3>

              {/* Textarea preview block */}
              <pre className="w-full max-h-[500px] overflow-y-auto bg-bg-secondary border border-white/5 rounded-xl p-6 text-xs text-slate-300 leading-relaxed font-sans whitespace-pre-wrap select-text">
                {synthesizedPreview}
              </pre>
            </div>

          </div>
        )}

      </main>
    </div>
  );
}
