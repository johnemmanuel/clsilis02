import express from 'express';
import cors from 'cors';
import * as path from 'path';
import { AIService, SearchService, ScraperService, ExporterService } from '../../core/src';

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Main Workspace Root Directory
const WORKSPACE_DIR = 'd:\\projects\\singulariti\\research-assistant';

/**
 * Route: Analyze Prompt (Step 1)
 */
app.post('/api/analyze-prompt', async (req, res) => {
  const { prompt, model, geminiApiKey, anthropicApiKey } = req.body;
  console.log(`\n[Server] === RECEIVED PROMPT ANALYSIS REQUEST ===`);
  console.log(`[Server] Prompt: "${prompt}"`);
  console.log(`[Server] Model: "${model || 'gemini'}"`);

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    const aiService = new AIService({ geminiApiKey, anthropicApiKey });
    const analysis = await aiService.analyzePrompt(prompt, model || 'gemini');
    console.log(`[Server] Prompt analysis resolved successfully!`);
    console.log(`[Server] Generated Search Terms:`, analysis.searchTerms);
    console.log(`[Server] Generated Data Points:`, analysis.dataPoints.map(d => d.key));
    res.json(analysis);
  } catch (error: any) {
    console.error('Error in /api/analyze-prompt:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * Route: Search Query (Step 2)
 */
app.post('/api/search', async (req, res) => {
  const { query, engine, googleApiKey, googleCx } = req.body;
  console.log(`\n[Server] === RECEIVED SEARCH REQUEST ===`);
  console.log(`[Server] Query: "${query}"`);
  console.log(`[Server] Engine: "${engine || 'duckduckgo'}"`);

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  try {
    const searchService = new SearchService({ googleApiKey, googleCx });
    const results = await searchService.search(query, engine || 'duckduckgo');
    console.log(`[Server] Search resolved! Found ${results.length} results.`);
    res.json(results);
  } catch (error: any) {
    console.error('Error in /api/search:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * Route: Scrape Webpage & Extract Data Points (Step 3)
 */
app.post('/api/scrape-and-extract', async (req, res) => {
  const { url, searchTerms, dataPoints, model, geminiApiKey, anthropicApiKey } = req.body;

  if (!url || !dataPoints) {
    return res.status(400).json({ error: 'URL and dataPoints are required' });
  }

  try {
    const scraperService = new ScraperService();
    const aiService = new AIService({ geminiApiKey, anthropicApiKey });

    console.log(`Starting local residential IP scrape for: ${url}`);
    const scraped = await scraperService.scrape(url, searchTerms || []);

    console.log(`Scraping finished. Proceeding with AI structured data extraction...`);
    const extractedFacts = await aiService.extractDataPoints(
      scraped.textContent,
      dataPoints,
      model || 'gemini'
    );

    res.json({
      page: {
        url: scraped.url,
        title: scraped.title,
        excerpt: scraped.excerpt,
        siteName: scraped.siteName,
        confidenceScore: scraped.confidenceScore,
        confidenceRationale: scraped.confidenceRationale
      },
      facts: extractedFacts
    });
  } catch (error: any) {
    console.error(`Error in /api/scrape-and-extract for URL "${url}":`, error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * Route: Synthesize Report & Export File to Workspace (Step 4)
 */
app.post('/api/export', async (req, res) => {
  const { prompt, extractedFacts, format, formatType, fileName, model, geminiApiKey, anthropicApiKey } = req.body;

  if (!prompt || !extractedFacts) {
    return res.status(400).json({ error: 'Prompt and extractedFacts are required' });
  }

  try {
    const aiService = new AIService({ geminiApiKey, anthropicApiKey });
    const exporterService = new ExporterService();

    console.log('Synthesizing research report with AI engine...');
    const reportMarkdown = await aiService.synthesizeReport(
      prompt,
      extractedFacts,
      format || 'article',
      model || 'gemini'
    );

    const safeFileName = (fileName || `research_report_${Date.now()}`).replace(/[\\/:*?"<>|]/g, '_');
    const reportsDir = path.join(WORKSPACE_DIR, 'reports');
    
    let fileExt = '.md';
    if (formatType === 'word') fileExt = '.docx';
    if (formatType === 'pdf') fileExt = '.pdf';

    const finalPath = path.join(reportsDir, `${safeFileName}${fileExt}`);
    console.log(`Saving final report directly to local workspace path: ${finalPath}`);

    let exportedPath = '';
    if (formatType === 'word') {
      exportedPath = await exporterService.exportWord(reportMarkdown, finalPath);
    } else if (formatType === 'pdf') {
      exportedPath = await exporterService.exportPDF(reportMarkdown, finalPath);
    } else {
      exportedPath = await exporterService.exportMarkdown(reportMarkdown, finalPath);
    }

    res.json({
      success: true,
      filePath: exportedPath,
      preview: reportMarkdown
    });
  } catch (error: any) {
    console.error('Error in /api/export:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server started on Bun! Access locally at: http://localhost:${PORT}`);
});
