import { JSDOM } from 'jsdom';

async function testYahoo() {
  const query = 'TypeScript Bun';
  console.log(`=== TESTING YAHOO SEARCH FALLBACK FOR: "${query}" ===`);

  try {
    const url = `https://search.yahoo.com/search?p=${encodeURIComponent(query)}`;
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });

    console.log(`\nResponse Status: HTTP ${response.status}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const html = await response.text();
    const dom = new JSDOM(html);
    const doc = dom.window.document;
    const results: any[] = [];

    // Yahoo standard search results have class "algo" or "dd card"
    const resultElements = doc.querySelectorAll('.algo');
    console.log(`Found result elements: ${resultElements.length}`);

    resultElements.forEach((el, idx) => {
      const titleEl = el.querySelector('h3 a, .compTitle a');
      const snippetEl = el.querySelector('.compText, div.compText');
      if (titleEl) {
        const title = titleEl.textContent?.trim() || '';
        const url = titleEl.getAttribute('href') || '';
        const snippet = snippetEl?.textContent?.trim() || '';
        if (title && url) {
          results.push({ title, url, snippet });
        }
      }
    });

    console.log(`\nParsed successfully: ${results.length} results found.`);
    results.slice(0, 3).forEach((r, idx) => {
      console.log(`  [${idx+1}] ${r.title} -> ${r.url}`);
    });
  } catch (err: any) {
    console.error(`✗ Yahoo Search failed: ${err.message}`);
  }
}

testYahoo();
