import { JSDOM } from 'jsdom';

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export class SearchService {
  private googleApiKey?: string;
  private googleCx?: string;

  constructor(config: { googleApiKey?: string; googleCx?: string }) {
    this.googleApiKey = config.googleApiKey;
    this.googleCx = config.googleCx;
  }

  /**
   * Fires a search query to the selected engine, with automatic free fallback engine failover.
   */
  async search(query: string, engine: 'duckduckgo' | 'google' = 'duckduckgo'): Promise<SearchResult[]> {
    if (engine === 'google' && this.googleApiKey && this.googleCx) {
      return this.searchGoogle(query);
    }
    
    try {
      console.log(`[Search Service] Attempting DuckDuckGo search for: "${query}"`);
      const results = await this.searchDuckDuckGo(query);
      if (results.length > 0) {
        console.log(`[Search Service] DuckDuckGo search resolved successfully. Found ${results.length} results.`);
        return results;
      }
      console.warn('[Search Service] DuckDuckGo returned 0 results. Failing over to Yahoo Search...');
    } catch (error: any) {
      console.warn(`[Search Service] DuckDuckGo search hit rate limits or errors: ${error.message}. Failing over to Yahoo Search...`);
    }

    // Failover silently to Yahoo Search to bypass rate limits or blocks
    return this.searchYahoo(query);
  }

  /**
   * DuckDuckGo free search result HTML scraper.
   */
  private async searchDuckDuckGo(query: string): Promise<SearchResult[]> {
    const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });

    // Treat HTTP 202 (bot accepted/challenge redirection page) as 0 results to trigger failover
    if (response.status === 202) {
      console.warn('[Search Service] DuckDuckGo returned HTTP 202 (Bot Redirection/Challenge page).');
      return [];
    }

    if (!response.ok) {
      throw new Error(`DuckDuckGo search failed with status ${response.status}`);
    }

    const html = await response.text();
    const dom = new JSDOM(html);
    const doc = dom.window.document;
    const results: SearchResult[] = [];

    const resultElements = doc.querySelectorAll('.web-result');
    resultElements.forEach((el) => {
      const titleEl = el.querySelector('.result__a');
      const snippetEl = el.querySelector('.result__snippet');
      if (titleEl) {
        const title = titleEl.textContent?.trim() || '';
        const rawUrl = titleEl.getAttribute('href') || '';
        
        // DuckDuckGo redirects standard links through /l/?uddg=URL, let's decode it
        let url = rawUrl;
        if (rawUrl.includes('uddg=')) {
          const parts = rawUrl.split('uddg=');
          if (parts[1]) {
            url = decodeURIComponent(parts[1].split('&')[0]);
          }
        }
        
        const snippet = snippetEl?.textContent?.trim() || '';
        if (title && url) {
          results.push({ title, url, snippet });
        }
      }
    });

    return results;
  }

  /**
   * Yahoo Search free HTML scraper (failsafe fallback).
   * Highly resilient to bot rate limits, providing excellent secondary search yields.
   */
  private async searchYahoo(query: string): Promise<SearchResult[]> {
    console.log(`[Search Service] Executing Yahoo search failover for: "${query}"`);
    const url = `https://search.yahoo.com/search?p=${encodeURIComponent(query)}`;
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
      },
    });

    if (!response.ok) {
      throw new Error(`Yahoo Search failed with status ${response.status}`);
    }

    const html = await response.text();
    const dom = new JSDOM(html);
    const doc = dom.window.document;
    const results: SearchResult[] = [];

    // Yahoo standard search results have class "algo"
    const resultElements = doc.querySelectorAll('.algo');
    resultElements.forEach((el) => {
      const titleEl = el.querySelector('h3 a, .compTitle a');
      const snippetEl = el.querySelector('.compText, div.compText');
      if (titleEl) {
        const title = titleEl.textContent?.trim() || '';
        const rawUrl = titleEl.getAttribute('href') || '';
        
        // Yahoo redirects standard links through /RU=URL/RK=2/..., let's extract the clean direct target URL
        let url = rawUrl;
        if (rawUrl.includes('/RU=')) {
          const parts = rawUrl.split('/RU=');
          if (parts[1]) {
            url = decodeURIComponent(parts[1].split('/')[0]);
          }
        }

        const snippet = snippetEl?.textContent?.trim() || '';
        if (title && url) {
          results.push({ title, url, snippet });
        }
      }
    });

    console.log(`[Search Service] Yahoo search failover completed successfully. Found ${results.length} results.`);
    return results;
  }

  /**
   * Google Custom Search official JSON API.
   */
  private async searchGoogle(query: string): Promise<SearchResult[]> {
    const url = `https://www.googleapis.com/customsearch/v1?key=${this.googleApiKey}&cx=${this.googleCx}&q=${encodeURIComponent(query)}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Google Custom Search failed with status ${response.status}`);
    }

    const data = await response.json();
    const results: SearchResult[] = [];

    if (data.items && Array.isArray(data.items)) {
      data.items.forEach((item: any) => {
        results.push({
          title: item.title || '',
          url: item.link || '',
          snippet: item.snippet || '',
        });
      });
    }

    return results;
  }
}
