import { chromium } from 'playwright';
import { JSDOM } from 'jsdom';
import { Readability } from '@mozilla/readability';

export interface ScrapedPage {
  url: string;
  title: string;
  textContent: string;
  excerpt: string;
  byline: string;
  siteName: string;
  confidenceScore: 'high' | 'medium' | 'low';
  confidenceRationale: string;
}

export class ScraperService {
  /**
   * Main scrape entrypoint. Resolves via ultra-fast, zero-overhead HTTP Fetch first.
   * Seamlessly fails over to Playwright Headless Chromium (with Windows-optimized flags) if blocked.
   */
  async scrape(url: string, searchTerms: string[] = []): Promise<ScrapedPage> {
    console.log(`[Scraper Service] Starting hybrid scrape for: "${url}"`);

    // --- STAGE 1: Fast HTTP Fetch + JSDOM ---
    try {
      console.log(`[Scraper Service] [Stage 1] Attempting fast direct HTTP fetch...`);
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
        },
      });

      if (response.ok) {
        const html = await response.text();
        const dom = new JSDOM(html, { url });
        const reader = new Readability(dom.window.document);
        const article = reader.parse();

        // If Readability extracted a solid chunk of article text, resolve immediately!
        if (article && article.textContent && article.textContent.trim().length > 600) {
          console.log(`[Scraper Service] [Stage 1] Fast fetch succeeded! Isolated ${article.textContent.length} characters of clean text.`);
          return this.compileScrapedPage(url, article, searchTerms);
        }
      }
      console.warn(`[Scraper Service] [Stage 1] Fast fetch returned limited text or failed. Proceeding to Playwright failover...`);
    } catch (fetchErr: any) {
      console.warn(`[Scraper Service] [Stage 1] Direct fetch errored: ${fetchErr.message}. Proceeding to Playwright failover...`);
    }

    // --- STAGE 2: Playwright Headless Chromium Fallback ---
    console.log(`[Scraper Service] [Stage 2] Spawning headless Chromium shell...`);
    
    // Windows-optimized stability flags to prevent Defender/Bun loopback pipe hangs
    const browser = await chromium.launch({
      headless: true,
      timeout: 5000, // 5 seconds launch timeout (prevents loopback pipe hangs!)
      args: [
        '--disable-blink-features=AutomationControlled',
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-gpu',
        '--disable-software-rasterizer',
        '--single-process',
        '--disable-dev-shm-usage',
      ]
    });

    try {
      const context = await browser.newContext({
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        viewport: { width: 1280, height: 720 },
        locale: 'en-US',
      });

      // Mask automation properties
      await context.addInitScript(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
      });

      const page = await context.newPage();

      // Enable aggressive resource blocking to save bandwidth and speed up page load
      await page.route('**/*', (route) => {
        const type = route.request().resourceType();
        if (['image', 'stylesheet', 'font', 'media'].includes(type)) {
          route.abort();
        } else {
          route.continue();
        }
      });

      // Navigate and wait for network activity to settle
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 5000 });

      const html = await page.content();
      await page.close();
      await context.close();

      // Extract core content via Readability
      const dom = new JSDOM(html, { url });
      const reader = new Readability(dom.window.document);
      const article = reader.parse();

      if (!article) {
        throw new Error('Failed to parse clean text from page DOM using Readability.');
      }

      console.log(`[Scraper Service] [Stage 2] Playwright scrape succeeded! Isolated ${article.textContent.length} characters.`);
      return this.compileScrapedPage(url, article, searchTerms);

    } catch (error: any) {
      throw new Error(`Scraping failed for URL "${url}": ${error.message}`);
    } finally {
      await browser.close();
    }
  }

  /**
   * Helper: Compiles raw parsed article details into a standardized ScrapedPage output with confidence scores.
   */
  private compileScrapedPage(url: string, article: any, searchTerms: string[]): ScrapedPage {
    const textContent = article.textContent || '';
    const lowerContent = textContent.toLowerCase();
    let matchCount = 0;

    searchTerms.forEach(term => {
      const words = term.toLowerCase().split(/\s+/);
      words.forEach(word => {
        if (word.length > 2 && lowerContent.includes(word)) {
          matchCount++;
        }
      });
    });

    let confidenceScore: 'high' | 'medium' | 'low' = 'low';
    let confidenceRationale = 'Contains minimal matching research keywords in the core article body.';

    if (matchCount > 15) {
      confidenceScore = 'high';
      confidenceRationale = 'Highly relevant. Contains multiple specific keywords relating to your search query in the primary text.';
    } else if (matchCount > 5) {
      confidenceScore = 'medium';
      confidenceRationale = 'Moderately relevant. Mentions the primary concepts, but covers them as part of a broader topic.';
    }

    return {
      url,
      title: article.title || 'Untitled Page',
      textContent: article.textContent || '',
      excerpt: article.excerpt || '',
      byline: article.byline || '',
      siteName: article.siteName || new URL(url).hostname,
      confidenceScore,
      confidenceRationale,
    };
  }
}
