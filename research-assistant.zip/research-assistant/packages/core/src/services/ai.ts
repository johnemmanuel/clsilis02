import { GoogleGenerativeAI } from '@google/generative-ai';
import Anthropic from '@anthropic-ai/sdk';

export interface PromptAnalysis {
  searchTerms: string[];
  dataPoints: {
    key: string;
    description: string;
    type: 'string' | 'number' | 'boolean' | 'array';
  }[];
}

export interface ExtractedData {
  [key: string]: any;
}

export class AIService {
  private geminiClient?: GoogleGenerativeAI;
  private anthropicClient?: Anthropic;

  constructor(config: { geminiApiKey?: string; anthropicApiKey?: string }) {
    if (config.geminiApiKey) {
      this.geminiClient = new GoogleGenerativeAI(config.geminiApiKey);
    }
    if (config.anthropicApiKey) {
      this.anthropicClient = new Anthropic({ apiKey: config.anthropicApiKey });
    }
  }

  /**
   * Internal Helper: Executes a Gemini prompt with automatic model name fallback.
   * Resolves 404 / unsupported model errors by dynamically cycling through valid model candidates.
   */
  private async generateGeminiContent(
    promptText: string,
    options?: { jsonMode?: boolean }
  ): Promise<string> {
    if (!this.geminiClient) throw new Error('Gemini API key is not configured.');

    // Comprehensive list of fallback model candidates in order of preference
    const candidates = [
      'gemini-1.5-flash',
      'gemini-1.5-flash-latest',
      'gemini-2.5-flash',
      'gemini-2.0-flash',
      'gemini-1.5-pro',
      'gemini-pro'
    ];

    let lastError: any = null;

    for (const modelName of candidates) {
      try {
        console.log(`[Gemini Client] Attempting execution with model: ${modelName}`);
        const geminiModel = this.geminiClient.getGenerativeModel({
          model: modelName,
          generationConfig: options?.jsonMode ? { responseMimeType: 'application/json' } : undefined,
        });

        const response = await geminiModel.generateContent({
          contents: [{ role: 'user', parts: [{ text: promptText }] }],
        });

        const text = response.response.text();
        if (text) {
          console.log(`[Gemini Client] Successfully resolved execution using model: ${modelName}`);
          return text;
        }
      } catch (err: any) {
        lastError = err;
        const msg = err.message || '';
        
        // If it's an API Key or auth issue, fail immediately to prevent infinite retries
        if (msg.includes('API key') || msg.includes('403') || msg.includes('401')) {
          throw err;
        }

        // If it's a 404 / Not Found / Unsupported model name error, log a warning and try the next candidate
        if (msg.includes('not found') || msg.includes('404') || msg.includes('not supported') || msg.includes('unsupported')) {
          console.warn(`[Gemini Client] Model name "${modelName}" returned 404 or is not supported. Retrying next candidate...`);
          continue;
        }

        // Otherwise, log error and try next candidate as a precaution
        console.warn(`[Gemini Client] Warning during execution with "${modelName}": ${msg}. Trying next candidate...`);
        continue;
      }
    }

    throw new Error(`All Gemini model candidates failed. Last error: ${lastError?.message || lastError}`);
  }

  /**
   * Analyzes the user's research request prompt to extract inferred search queries and extraction data points.
   */
  async analyzePrompt(prompt: string, model: 'gemini' | 'claude' = 'gemini'): Promise<PromptAnalysis> {
    const systemPrompt = `You are a research analysis system. Your task is to analyze the user's research request prompt and output:
1. A list of 3-5 short, highly effective search queries (2-4 keywords each, e.g., "solid state battery 2026" or "pilot plant capacity"). Do NOT generate long sentences or overly specific phrases as search engines will return zero results.
2. A list of key data points (schema) that should be extracted from the resulting articles. Each data point must have a unique 'key' (camelCase), a 'description' of what it is, and a data 'type' (choose from: 'string', 'number', 'boolean', 'array').

You MUST respond with a valid JSON object matching this schema:
{
  "searchTerms": ["string"],
  "dataPoints": [
    { "key": "string", "description": "string", "type": "string" }
  ]
}`;

    if (model === 'gemini') {
      const text = await this.generateGeminiContent(
        `System: ${systemPrompt}\nUser Request: ${prompt}`,
        { jsonMode: true }
      );
      
      // Strip any markdown code blocks if the model accidentally included them in jsonMode
      const jsonStart = text.indexOf('{');
      const jsonEnd = text.lastIndexOf('}') + 1;
      return JSON.parse(text.substring(jsonStart, jsonEnd)) as PromptAnalysis;
    } else {
      if (!this.anthropicClient) throw new Error('Anthropic API key is not configured.');
      const response = await this.anthropicClient.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 1000,
        messages: [{ role: 'user', content: `System: ${systemPrompt}\nUser Request: ${prompt}` }],
      });
      const content = response.content[0].type === 'text' ? response.content[0].text : '';
      const jsonStart = content.indexOf('{');
      const jsonEnd = content.lastIndexOf('}') + 1;
      return JSON.parse(content.substring(jsonStart, jsonEnd)) as PromptAnalysis;
    }
  }

  /**
   * Extracts structured details from a website's text content given a target extraction schema.
   */
  async extractDataPoints(
    scrapedContent: string,
    dataPoints: PromptAnalysis['dataPoints'],
    model: 'gemini' | 'claude' = 'gemini'
  ): Promise<ExtractedData> {
    const schemaStr = JSON.stringify(dataPoints, null, 2);
    const systemPrompt = `You are a data extraction system. Your task is to read the provided web page content and extract the requested data points.
If a data point cannot be found or inferred from the content, set its value to null.
Ensure the extracted values exactly match their expected data types ('string', 'number', 'boolean', 'array').

Requested Data Schema:
${schemaStr}

You MUST respond with a single valid JSON object containing the extracted key-value pairs.`;

    if (model === 'gemini') {
      const text = await this.generateGeminiContent(
        `System: ${systemPrompt}\nWeb Content:\n${scrapedContent}`,
        { jsonMode: true }
      );
      
      const jsonStart = text.indexOf('{');
      const jsonEnd = text.lastIndexOf('}') + 1;
      return JSON.parse(text.substring(jsonStart, jsonEnd));
    } else {
      if (!this.anthropicClient) throw new Error('Anthropic API key is not configured.');
      const response = await this.anthropicClient.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 2000,
        messages: [{ role: 'user', content: `System: ${systemPrompt}\nWeb Content:\n${scrapedContent}` }],
      });
      const content = response.content[0].type === 'text' ? response.content[0].text : '';
      const jsonStart = content.indexOf('{');
      const jsonEnd = content.lastIndexOf('}') + 1;
      return JSON.parse(content.substring(jsonStart, jsonEnd));
    }
  }

  /**
   * Synthesizes all gathered structured facts into a cohesive final research report.
   */
  async synthesizeReport(
    originalPrompt: string,
    extractedFacts: ExtractedData[],
    format: 'article' | 'comparison' | 'summary' = 'article',
    model: 'gemini' | 'claude' = 'gemini'
  ): Promise<string> {
    const factsStr = JSON.stringify(extractedFacts, null, 2);
    const formatInstruction = {
      article: 'A deeply detailed, narrative research article with rich headings, paragraphs, and citations.',
      comparison: 'A structured comparison report highlighting key similarities and differences, including markdown tables comparing the different sources.',
      summary: 'A concise executive summary with bullet points, main findings, and key takeaways.'
    }[format];

    const systemPrompt = `You are a senior research analyst. Your task is to write a highly professional research report in Markdown format based on the original user prompt and a set of extracted structured data from several web sources.

Original Research Goal: "${originalPrompt}"
Format Style: ${formatInstruction}
Extracted Source Data:
${factsStr}

Guidelines:
1. Write in a clear, objective, and premium tone.
2. Structure the document beautifully using standard Markdown (H1, H2, lists, bold elements, tables).
3. Synthesize the raw source data into a single coherent narrative. Avoid just listing source 1, source 2.
4. If applicable, add a "Key Findings" table comparing details.
5. End with a summary of limitations (e.g., if any requested data points were missing from sources).

Output only the Markdown content. Do not include any HTML wraps or meta-commentary.`;

    if (model === 'gemini') {
      return await this.generateGeminiContent(systemPrompt);
    } else {
      if (!this.anthropicClient) throw new Error('Anthropic API key is not configured.');
      const response = await this.anthropicClient.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 4000,
        messages: [{ role: 'user', content: systemPrompt }],
      });
      return response.content[0].type === 'text' ? response.content[0].text : '';
    }
  }
}
