import * as fs from 'fs';
import * as path from 'path';
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx';
import PDFDocument from 'pdfkit';

export class ExporterService {
  /**
   * Exports raw Markdown content directly to a file in the workspace.
   */
  async exportMarkdown(content: string, outputPath: string): Promise<string> {
    const dir = path.dirname(outputPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(outputPath, content, 'utf-8');
    return outputPath;
  }

  /**
   * Compiles and exports Markdown into a native Word .docx file.
   */
  async exportWord(content: string, outputPath: string): Promise<string> {
    const dir = path.dirname(outputPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const lines = content.split('\n');
    const docChildren: any[] = [];

    lines.forEach((line) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('# ')) {
        docChildren.push(
          new Paragraph({
            text: trimmed.replace('# ', ''),
            heading: HeadingLevel.HEADING_1,
            spacing: { before: 240, after: 120 },
          })
        );
      } else if (trimmed.startsWith('## ')) {
        docChildren.push(
          new Paragraph({
            text: trimmed.replace('## ', ''),
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 180, after: 80 },
          })
        );
      } else if (trimmed.startsWith('### ')) {
        docChildren.push(
          new Paragraph({
            text: trimmed.replace('### ', ''),
            heading: HeadingLevel.HEADING_3,
            spacing: { before: 140, after: 60 },
          })
        );
      } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        docChildren.push(
          new Paragraph({
            children: [new TextRun(trimmed.substring(2))],
            bullet: { level: 0 },
            spacing: { after: 60 },
          })
        );
      } else if (trimmed) {
        docChildren.push(
          new Paragraph({
            children: [new TextRun(trimmed)],
            spacing: { after: 120 },
          })
        );
      }
    });

    const doc = new Document({
      sections: [
        {
          properties: {},
          children: docChildren,
        },
      ],
    });

    const buffer = await Packer.toBuffer(doc);
    fs.writeFileSync(outputPath, buffer);
    return outputPath;
  }

  /**
   * Compiles and renders Markdown content to a PDF document using PDFKit.
   */
  async exportPDF(content: string, outputPath: string): Promise<string> {
    const dir = path.dirname(outputPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({ margin: 50 });
        const stream = fs.createWriteStream(outputPath);
        doc.pipe(stream);

        const lines = content.split('\n');
        lines.forEach((line) => {
          const trimmed = line.trim();
          if (trimmed.startsWith('# ')) {
            doc.font('Helvetica-Bold').fontSize(22).fillColor('#1e1b4b').text(trimmed.replace('# ', ''), { paragraphGap: 14 });
          } else if (trimmed.startsWith('## ')) {
            doc.font('Helvetica-Bold').fontSize(15).fillColor('#312e81').text(trimmed.replace('## ', ''), { paragraphGap: 10 });
          } else if (trimmed.startsWith('### ')) {
            doc.font('Helvetica-Bold').fontSize(11).fillColor('#4338ca').text(trimmed.replace('### ', ''), { paragraphGap: 7 });
          } else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
            doc.font('Helvetica').fontSize(9.5).fillColor('#334155').text(`•  ${trimmed.substring(2)}`, { indent: 15, paragraphGap: 5 });
          } else if (trimmed) {
            doc.font('Helvetica').fontSize(9.5).fillColor('#334155').text(trimmed, { paragraphGap: 9, align: 'justify' });
          } else {
            doc.moveDown(0.4);
          }
        });

        doc.end();
        stream.on('finish', () => resolve(outputPath));
        stream.on('error', (err) => reject(err));
      } catch (error) {
        reject(error);
      }
    });
  }
}
