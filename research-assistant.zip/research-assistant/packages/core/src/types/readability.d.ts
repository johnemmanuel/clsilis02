declare module '@mozilla/readability' {
  export interface ReadabilityResult {
    title: string;
    content: string;
    textContent: string;
    length: number;
    excerpt: string;
    byline: string;
    dir: string;
    siteName: string;
  }

  export class Readability {
    constructor(doc: Document, options?: any);
    parse(): ReadabilityResult | null;
  }
}
