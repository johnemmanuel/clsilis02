import { SearchService } from './services/search';
import { ExporterService } from './services/exporter';
import * as path from 'path';
import * as fs from 'fs';

async function runTests() {
  console.log('=== STARTING WORKSPACE SERVICE INTEGRATION TESTS ===\n');

  // Test 1: Search Service (DuckDuckGo Scraper)
  console.log('[Test 1] Initializing Search Service & scraping DuckDuckGo...');
  const searchService = new SearchService({});
  try {
    const results = await searchService.search('TypeScript Bun cross-platform', 'duckduckgo');
    console.log(`✓ Search resolved successfully! Found ${results.length} results.`);
    if (results.length > 0) {
      console.log(`  Top Result: "${results[0].title}" - ${results[0].url}\n`);
    } else {
      console.log('  ⚠ Warning: DuckDuckGo returned 0 results. Might be rate limited.');
    }
  } catch (err: any) {
    console.error(`✗ Search Service failed: ${err.message}\n`);
  }

  // Test 2: Exporter Service (Markdown, DOCX, and PDF compile)
  console.log('[Test 2] Initializing Exporter Service...');
  const exporterService = new ExporterService();
  const testOutputDir = path.join(__dirname, '..', 'reports_test');
  
  if (!fs.existsSync(testOutputDir)) {
    fs.mkdirSync(testOutputDir, { recursive: true });
  }

  const dummyMarkdown = `# Integrated Test Report\n\nGenerated during integration verification.\n\n## Key Findings\n- Service layers compile cleanly.\n- Bun runtime executes TypeScript natively.\n- System structure decoupled successfully.`;

  try {
    const mdPath = path.join(testOutputDir, 'test_report.md');
    await exporterService.exportMarkdown(dummyMarkdown, mdPath);
    console.log(`✓ Markdown exported successfully to: ${mdPath}`);

    const docxPath = path.join(testOutputDir, 'test_report.docx');
    await exporterService.exportWord(dummyMarkdown, docxPath);
    console.log(`✓ Word document (.docx) packed successfully to: ${docxPath}`);

    const pdfPath = path.join(testOutputDir, 'test_report.pdf');
    await exporterService.exportPDF(dummyMarkdown, pdfPath);
    console.log(`✓ PDF compiled successfully to: ${pdfPath}\n`);

    console.log('=== ALL WORKSPACE INTEGRATION TESTS PASSED ===');
  } catch (err: any) {
    console.error(`✗ Exporter Service failed: ${err.message}\n`);
  }
}

runTests();
