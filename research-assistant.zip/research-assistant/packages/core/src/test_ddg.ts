import { SearchService } from './services/search';

async function testSearch() {
  const query = 'TypeScript Bun';
  const engine = 'duckduckgo';
  console.log(`=== DIAGNOSING SEARCH ENGINE FOR QUERY: "${query}" ===`);
  
  const searchService = new SearchService({});
  try {
    const results = await searchService.search(query, engine);
    console.log(`\nResults parsed successfully: ${results.length} found.`);
    if (results.length > 0) {
      results.slice(0, 3).forEach((r, idx) => {
        console.log(`  [${idx+1}] ${r.title} -> ${r.url}`);
      });
    } else {
      console.log('  ⚠ DDG parsed 0 results.');
      
      // Let's print what DDG HTML is actually returning!
      const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
        },
      });
      console.log(`\n[Direct Fetch Status] HTTP ${response.status}`);
      const html = await response.text();
      console.log(`[Direct Fetch HTML First 400 Characters]:\n${html.substring(0, 400)}`);
      
      const containsCaptcha = html.toLowerCase().includes('captcha') || html.toLowerCase().includes('ddg-captcha') || html.toLowerCase().includes('robot');
      console.log(`\nContains robot/captcha warnings: ${containsCaptcha}`);
    }
  } catch (err: any) {
    console.error(`✗ Test failed with error: ${err.message}`);
  }
}

testSearch();
