# Technical Plan & Architectural Design: Research Assistant

This document outlines the comprehensive technology stack, system architecture, scraping bypass strategy, high-fidelity UI design, and complete implementation roadmap for the open-source, local-first **Research Assistant**.

---

## 1. Technology Stack

To ensure that the application is **100% free (excluding AI tokens)**, highly performant, and easily deployable as a standalone local app or future VS Code extension, we use a modular, decoupled **TypeScript monorepo**:

| Layer | Selected Tech | Rationale |
| :--- | :--- | :--- |
| **Core Architecture** | **Bun Workspaces / Monorepo** | Decouples business logic (`packages/core`) from execution environments. Bun is extremely fast, runs TypeScript natively, and manages packages in milliseconds. |
| **Frontend UI** | **React + TypeScript + Vite** | High-performance client-side rendering, instant bundling, type safety, and rich interactive wizard state management. |
| **Styling** | **Tailwind CSS v4** | CSS-first configuration, compile-time performance, modern utility layout features, and native dark-mode/gradients without heavy runtime scripts. |
| **Backend Host** | **Bun + Express (or Hono)** | TypeScript-first server running natively on Bun, handling static page routing, local REST endpoints, and direct local workspace file system writing. |
| **Search Engine** | **DuckDuckGo HTML + Google CSE** | 100% free search engines: DuckDuckGo requires zero credentials, and Google Custom Search API is free for 100 queries/day. |
| **Local Scraping** | **Playwright + Playwright Stealth** | Direct local Chromium launching utilizing the host's residential home IP. Pristine reputation bypasses Cloudflare on target sites (e.g., Newegg) for free. |
| **Text Synthesis** | **Mozilla Readability** | Extracts core article body text, headings, and lists. Strips headers, menus, ads, and footers, cutting token ingestion costs by up to 95%. |
| **File Exporters** | `markdown`, `pdfkit`, `docx` | Native document compiling to save reports directly into the active local workspace. |

---

## 2. System Architecture

The monorepo separates concerns into clean boundaries, using TypeScript project references to link packages.

```
                      [ Root Workspace ]
                              │
         ┌────────────────────┼────────────────────┐
         ▼                    ▼                    ▼
packages/frontend       packages/server       packages/core
 (React & Tailwind)     (Express Host API)   (Business Logic)
         │                    │                    │
         │                    ▼                    ▼
         └─────────────► [ REST HTTP ] ───────► [ Services ]
                                                   ├─ ai.ts
                                                   ├─ search.ts
                                                   ├─ scraper.ts
                                                   └─ exporter.ts
```

### Core Module Breakdown (`packages/core`)

#### A. AI Service (`src/services/ai.ts`)
*   **APIs**: Google Gemini SDK (`@google/generative-ai`) and Anthropic SDK (`@anthropic-ai/sdk`).
*   **Responsibilities**:
    1.  **Prompt Analysis**: Parses user prompts to infer 3-5 hyper-focused search terms and compiles a JSON array of desired target data points (with descriptive keys and target types).
    2.  **Information Extraction**: Accepts scraped, cleaned text from multiple websites along with the extraction schema, and returns structured data fields.
    3.  **Synthesis & Formatting**: Suggests matching document templates (e.g., comparison table, comprehensive article, whitepaper) and synthesizes the finalized document.

#### B. Search Service (`src/services/search.ts`)
*   **APIs**: DuckDuckGo Scraper (scraping the standard low-bandwidth `html.duckduckgo.com` page) and Google Custom Search API.
*   **Responsibilities**:
    *   Fires parallel searches across the inferred search terms.
    *   Deduplicates, standardizes, and parses search results into standard objects (Title, URL, Snippet).

#### C. Local Scraping Service (`src/services/scraper.ts`)
*   **APIs**: Playwright (`chromium`), `playwright-extra`, `puppeteer-extra-plugin-stealth`, and `@mozilla/readability`.
*   **Responsibilities**:
    1.  **Anti-Bot Stealth**: Injects normal desktop navigator schemas, hides `webdriver` properties, rotates normal desktop User-Agents, and matches realistic device dimensions.
    2.  **Resource Blocking**: Intercepts requests and blocks images, fonts, styles, tracking, and media. This reduces network footprint by ~90%, loads pages in milliseconds, and avoids raising bot-detection alarms.
    3.  **Clean DOM Parsing**: Renders Javascript-heavy pages fully (waiting for network idle), extracts DOM HTML, runs `@mozilla/readability` to obtain the pure clean text, and calculates a confidence relevance score.

#### D. Exporter Service (`src/services/exporter.ts`)
*   **APIs**: Native file writers, `pdfkit` (or clean html-to-pdf), and the `docx` builder.
*   **Responsibilities**:
    *   Converts synthesized JSON/Markdown into rich files.
    *   Saves outputs directly to the designated output folder in the active local workspace.

---

## 3. High-Fidelity UI Design System (Tailwind CSS v4)

To create a premium, immersive interface, the UI implements a modern dark control center using Tailwind v4 custom themes:

*   **Colors**:
    *   **Background**: Deep Slate Gray (`bg-[#0b0f19]`) with high-contrast card blocks (`bg-[#161d30]/60`).
    *   **Borders & Cards**: Glassmorphism overlays using CSS `backdrop-filter: blur(12px)` and semi-transparent borders (`border-white/10`).
    *   **Accent Gradients**: Indigo-to-Violet (`from-indigo-500 to-violet-600`) as primary highlights.
    *   **Confidence Badges**: High = Emerald Green (`#10b981`), Medium = Amber (`#f59e0b`), Low = Slate (`#64748b`).
*   **Micro-Animations**:
    *   Smooth transitions (`transition-all duration-300`) on all interactive buttons, cards, and list elements.
    *   Pulse indicators and custom track sliders showing active scraping tasks.

---

## 4. Workflows

### A. Human-in-the-Loop (HITL) Workflow
A clean, four-step wizard that empowers the user to refine inputs at critical checkpoints:

1.  **Define**: Enter primary prompt, choose active AI engine (Gemini/Claude), search engine, and toggle workflow.
2.  **Refine**: AI renders inferred keywords as clickable, editable tags (add/remove) and data points as a modular checklist.
3.  **Select**: Grid displaying search findings. Each result features its confidence badge, AI rationale, and source details. Users toggle checkmarks to include/exclude URLs, and can paste custom URLs.
4.  **Export**: Shows a formatted Markdown live preview of the report alongside format template options (Markdown, PDF, DOCX). Clicking export saves the files directly to the workspace directory.

### B. Fully Automated Workflow
1.  User supplies prompt, maximum search links to parse, and output choice.
2.  The application enters a **Live Monitoring Dashboard**.
3.  A vertical timeline with active spinning loaders and indicator bars reports search activity, scraping counts, data extractions, and document synthesis in real time.
4.  The final report is generated and saved automatically to the workspace.

## 5. Desktop Packaging (Tauri v2 Architecture)

To bundle the application as a standalone desktop utility, we utilize **Tauri v2**. This replaces Electron with an ultra-lightweight native Rust container:

1. **Frontend Compilation**: React + Tailwind v4 is compiled to static assets in `packages/frontend/dist` using Vite (`bun run build`).
2. **Tauri Container**: Tauri loads these assets and renders them inside a native OS window using the Windows built-in **WebView2 (Chromium)** engine.
3. **Core Backend Sidecar**:
   - We compile our TS/Bun server and core scraping services into a single-file Windows executable binary using Bun's native compiler:
     ```bash
     bun build --compile ./packages/server/src/index.ts --outfile research-assistant-host.exe
     ```
   - Tauri bundles this binary as a **Sidecar Binary** inside the `src-tauri/binaries/` folder.
   - When the Tauri desktop app starts, the native Rust container launches this compiled sidecar server in the background and opens the React web client.
4. **Zero-Dependency Installer**: The final packaging compiles a standalone `.msi` Windows installer, `.dmg` for Mac, and `.deb` for Linux. The user needs zero external runtimes (no Node.js, Rust, or Bun installations required).

---

## 6. Cross-Platform Compatibility

The selection of **Tauri v2 + Bun + Playwright** guarantees native, seamless execution across Windows, macOS, and Linux out-of-the-box:

*   **Tauri Runtimes**: Tauri dynamically renders the UI using the host OS web engine (Windows WebView2/Chromium, macOS WebKit/Safari, Linux WebKitGTK).
*   **Bun Multi-Target Sidecars**: Bun's native single-file compiler creates optimized sidecar binaries for all target architectures from any build platform:
    *   Windows x64: `--target=bun-windows-x64`
    *   macOS Apple Silicon: `--target=bun-darwin-arm64`
    *   macOS Intel: `--target=bun-darwin-x64`
    *   Linux x64: `--target=bun-linux-x64`
*   **Playwright Browsers**: Playwright automatically downloads and runs the correct native headless browser binary for the host OS during initial installation.

---

## 7. Comprehensive Status Tracker

This tracker monitors progress across all components. Use it to keep track of implementation details.

| Phase | Component | Task Description | Target File / Location | Status | Notes / Progress |
| :--- | :--- | :--- | :--- | :---: | :--- |
| **1. Setup** | Monorepo | Initialize workspaces & configure root `package.json` | `/package.json` | 🟢 | Completed |
| **1. Setup** | Frontend | Install Vite + React + TS, and configure **Tailwind v4** | `/packages/frontend/` | 🟢 | Completed |
| **2. Core** | Core Services | Implement AI Service (Gemini & Claude integrations) | `/packages/core/src/services/ai.ts` | 🟢 | Completed |
| **2. Core** | Core Services | Implement Search Service (DuckDuckGo + Google Custom Search) | `/packages/core/src/services/search.ts` | 🟢 | Completed |
| **2. Core** | Core Services | Implement Local Playwright + Stealth + Resource Blocking Scraper | `/packages/core/src/services/scraper.ts` | 🟢 | Completed |
| **2. Core** | Core Services | Implement Exporter (Markdown, `.docx` compilation, PDF exporter) | `/packages/core/src/services/exporter.ts` | 🟢 | Completed |
| **3. Server** | Server Host | Build Express/Hono App running on Bun and configure REST routing | `/packages/server/src/index.ts` | 🟢 | Completed |
| **3. Server** | Server Host | Implement `/api` endpoints and local workspace file writers on Bun | `/packages/server/src/routes.ts` | 🟢 | Completed |
| **4. Client** | Frontend UI | Design Tailwind v4 Glassmorphism components & theme rules | `/packages/frontend/src/index.css` | 🟢 | Completed |
| **4. Client** | Frontend UI | Build step-by-step state engine & context managers | `/packages/frontend/src/context/` | 🟢 | Completed |
| **4. Client** | Frontend UI | Build HITL step interfaces (Define, Refine, Select, Export pages) | `/packages/frontend/src/components/` | 🟢 | Completed |
| **4. Client** | Frontend UI | Build Automated Dashboard and live logger system views | `/packages/frontend/src/components/` | 🟢 | Completed |
| **5. Testing** | Verification | Write integration tests and verify local Cloudflare bypass | `/packages/core/src/test_integration.ts` | 🟢 | Completed |
| **6. Packaging** | Desktop Shell | Set up Tauri v2 configuration and static asset loaders | `/src-tauri/tauri.conf.json` | 🔴 | Not Started |
| **6. Packaging** | Desktop Shell | Compile Bun backend sidecar and generate `.msi`/`.dmg`/`.deb` builders | `/src-tauri/binaries/` | 🔴 | Not Started |

*Status Legend: 🔴 Not Started | 🟡 In Progress | 🟢 Completed*
