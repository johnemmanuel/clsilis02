# Project: Research Assistant

## Overview

I want to develop a tool that will help me find information from the internet and create reports using them. The tool should be able to run in a fully automated way or should be able to work with a human in the loop.

### Human in the loop workflow

1. I provide a prompt in a user interface
2. The prompt is sent to an AI agent (gemini, claude etc. should be configurable)
3. The AI agent infers couple of search terms and displays on the interface along with suggestions of data points that will be extracted from the content
4. I review the terms and may either add to it or remove from it (search terms as well as data points)
5. The search terms are pushed to a search engine duckduckgo (default) or google, chosen from the UI
6. Results are scraped and displayed in the UI with confidence score on which links are good (high, medium, low)
7. I choose a few links and add to the choice with a custom link 
8. On submit, the app scrapes content from the selected links 
9. Content scraped is sent to the AI agent to extract content for the data points selected earlier
10. AI puts the extracted content into an appropriate format (eg. article format, simple document, content in tabular format etc), choices displayed in the UI. AI suggests formats based on the user prompt and the content available. 
11. Document content is saved to a user choice (displayed in the UI) - markdown, pdf, word
12. Document saved to current workspace.

NOTE: All user choices (but for dynamic choices based on results) can be sought upfront before starting the workflow.

### Fully automated workflow

User choices in the 'Human in the loop workflow' will be sought upfront after receiving the prompt and the agent has analyzed it.
The whole workflow will not be completed without human intervention. An additional user input though will be the number of links (high) that should be scraped.

## AI Agent Goals

The AI Agent must always ensure 2 things - 

- Understand well what the User is trying to study/research
- Understand which search engine results will be relevant to achieve user goals
- Understand and generate search terms that (based on the search engine) will get the best results to achieve user goals

## Technology Stack

The application must work on the desktop and integrate with an AI agent (gemini or claude etc).
So choose the best technology that will allow us to achieve goals with easier maintainance, easier integration with other AI agents (cloud or local). 